<?php

/**
 *
 * @link              http://www.wpdreamthemes.com
 * @since             1.0.0
 * @package           Manang Basecamp
 *
 * @wordpress-plugin
 * Plugin Name:       Manang Basecamp
 * Plugin URI:        http://www.wpdreamthemes.com/plugins/manang-basecamp
 * Description:       Registers custom post types and custom fields for the Manang theme. This plugin must be installed in order to the proper functioning of the theme.
 * Version:           1.0.0
 * Author:            Dream Themes
 * Author URI:        http://www.wpdreamthemes.com
 * License:           GPL-3.0+
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       manang-basecamp
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Set up and initialize
 */
class manang_basecamp {

	private static $instance;

	/**
	 * Actions setup
	 */
	public function __construct() {

		add_action( 'plugins_loaded', array( $this, 'constants' ), 2 );
		add_action( 'plugins_loaded', array( $this, 'i18n' ), 3 );
		add_action( 'plugins_loaded', array( $this, 'includes' ), 4 );
		add_action( 'admin_notices', array( $this, 'admin_notice' ), 4 );
		add_action('admin_enqueue_scripts', array($this, 'manang_basecamp_admin_scripts' ), 4);
	}

		function manang_basecamp_admin_scripts() {
		    wp_register_script('manang-basecamp-upload-js', plugins_url('/js/upload.js',__FILE__), array('jquery'));
		    wp_enqueue_script('manang-basecamp-upload-js');
		    wp_register_script('manang-basecamp-repeatable-js', plugins_url('/js/repeatable.js',__FILE__), array('jquery'));
		    wp_enqueue_script('manang-basecamp-repeatable-js');
		    wp_enqueue_style( 'manang-basecamp-gallery-css', plugins_url('/css/gallery.css',__FILE__) );
		    // wp_enqueue_style( 'ionicons-css', plugins_url('/css/ionicons.min.css',__FILE__) );
        	//For image icon
        	wp_enqueue_script( 'jqueryui-selectt', plugins_url('/js/jquery.selectBoxIt.min.js',__FILE__), array(), '21112016', true );
        	 wp_enqueue_style( 'slectjs', plugins_url('/css/jquery.selectBoxIt.css',__FILE__) );
		}

	/**
	 * Constants
	 */
	function constants() {

		define( 'RE_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'RE_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );
	}

	/**
	 * Includes
	 */
	function includes() {

		//Post types
		require_once( RE_DIR . 'inc/manang-basecamp-post-types.php' );
		//Metaboxes
		require_once( RE_DIR . 'inc/events.php' );
		require_once( RE_DIR . 'inc/manang-basecamp-metabox.php' );

	}

	/**
	 * Translations
	 */
	function i18n() {
		load_plugin_textdomain( 'manang-basecamp', false, 'manang-basecamp/languages' );
	}

	/**
	 * Admin notice
	 */
	function admin_notice() {
		$theme  = wp_get_theme();
		$parent = wp_get_theme()->parent();
		if ( ($theme != 'Manang' )  ) {
		    echo '<div class="error">';
		    echo 	'<p>' . __('Please note that the <strong>Manang Basecamp</strong> plugin is meant to be used only with the Manang theme</p>', 'manang-basecamp');
		    echo '</div>';
		}
	}

	/**
	 * Returns the instance.
	 */
	public static function get_instance() {

		if ( !self::$instance )
			self::$instance = new self;

		return self::$instance;
	}
}

function manang_basecamp_plugin() {
	if ( !function_exists('wpcf_init') ) //Make sure the Types plugin isn't active
		return manang_basecamp::get_instance();
}
add_action('plugins_loaded', 'manang_basecamp_plugin', 1);

register_activation_hook( __FILE__, 'manang_rewrite_flush' );