=== Plugin Name ===
Contributors: Dream Themes
Tags: custom post types, custom fields
Requires at least: 4.5
Tested up to: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Registers custom post types and custom fields for the Resortica theme

== Description ==

**The Manang Basecamp plugin is meant to be used only with the Resortica WordPress theme.**

This plugin registers custom post types and custom fields that are needed in the [Resortica theme]

== Installation ==

1. Go to Plugins > Add New and search for Manang Basecamp. Install and activate it.

== Changelog ==

= 1.0 =
* Initial version