<?php
function manang_basecamp_event_callback() {
    $prefix = 'manang_basecamp_event_';
    $custom_meta_fields = array(
        array(
            'label'=> 'Start date',
            'desc'  => 'Format: mm-dd-yyyy',
            'id'    => $prefix.'start_date',
            'type'  => 'text'
        ),
        array(
            'label'=> 'End Date',
            'desc'  => '',
            'id'    => $prefix.'end_date',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Start Time',
            'desc'  => '',
            'id'    => $prefix.'start_time',
            'type'  => 'text'
        ),

        array(
            'label'=> 'End Time',
            'desc'  => '',
            'id'    => $prefix.'end_time',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Ticket Price',
            'desc'  => '',
            'id'    => $prefix.'ticket_price',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Category',
            'desc'  => '',
            'id'    => $prefix.'category',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Location',
            'desc'  => '',
            'id'    => $prefix.'location',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Button Text',
            'desc'  => '',
            'id'    => $prefix.'button_text',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Button Link',
            'desc'  => '',
            'id'    => $prefix.'button_link',
            'type'  => 'text'
        ),

        array(
            'label' => 'Organizers',
            'desc'  => 'Add Ordganizers.',
            'id'    => $prefix.'organizers',
            'type'  => 'repeatable'
        ),

    );
    global $post;
    // Use nonce for verification
    echo '<input type="hidden" name="manang_basecamp_event_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';

    // Begin the field table and loop
    echo '<table class="form-table">';
    foreach ($custom_meta_fields as $field) {
        // get value of this field if it exists for this post
        $meta = get_post_meta($post->ID, $field['id'], true);
        // begin a table row with
        echo '<tr>
                <th><label for="'.$field['id'].'">'.$field['label'].'</label></th>
                <td>';
                switch($field['type']) {
                    case 'text':
                        echo '<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="30" />
                            <br /><span class="description">'.$field['desc'].'</span>';
                    break;

                    case 'repeatable':
                        echo '
                                <ul id="'.$field['id'].'-repeatable" class="custom_repeatable">';
                        $i = 0;

                        if ($meta) {
                            foreach($meta as $row) {
                                echo '<li>
                                            <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$row.'" size="30" />';?>
                                        <?php
                                         echo '<a class="repeatable-remove button" href="#">-</a></li>';
                                $i++;
                            }
                        } else {
                            echo '<li>
                                       <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$meta.'" size="30" />

                                            <a class="repeatable-remove button" href="#">-</a></li>';
                        }
                        echo '</ul><a class="repeatable-add button" href="#">Add</a>
                            ';
                    break;
                } //end switch
        echo '</td></tr>';
    } // end foreach
    echo '</table>'; // end table
}

function manang_basecamp_save_event_meta($post_id, $post) {
    $prefix = 'manang_basecamp_event_';
    $custom_meta_fields = array(
        array(
            'label'=> 'Start date',
            'desc'  => 'Format: mm-dd-yyyy',
            'id'    => $prefix.'start_date',
            'type'  => 'text'
        ),
        array(
            'label'=> 'End Date',
            'desc'  => '',
            'id'    => $prefix.'end_date',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Start Time',
            'desc'  => '',
            'id'    => $prefix.'start_time',
            'type'  => 'text'
        ),

        array(
            'label'=> 'End Time',
            'desc'  => '',
            'id'    => $prefix.'end_time',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Ticket Price',
            'desc'  => '',
            'id'    => $prefix.'ticket_price',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Category',
            'desc'  => '',
            'id'    => $prefix.'category',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Location',
            'desc'  => '',
            'id'    => $prefix.'location',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Button Text',
            'desc'  => '',
            'id'    => $prefix.'button_text',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Button Link',
            'desc'  => '',
            'id'    => $prefix.'button_link',
            'type'  => 'text'
        ),

        array(
            'label' => 'Organizers',
            'desc'  => 'Add Ordganizers.',
            'id'    => $prefix.'organizers',
            'type'  => 'repeatable'
        ),
    );

   if (empty($_POST['manang_basecamp_event_nonce'])){
    return $post_id;
   }
    // verify nonce
    if (!wp_verify_nonce($_POST['manang_basecamp_event_nonce'], basename(__FILE__)))
        return $post_id;
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;
    // check permissions
    if ( !current_user_can( 'edit_post', $post->ID ))
            return $post->ID;

    // loop through fields and save the data
    foreach ($custom_meta_fields as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    } // end foreach
}
add_action('save_post', 'manang_basecamp_save_event_meta', 1, 2);