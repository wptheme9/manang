<?php
// Register Custom Post Types
if(!function_exists('manang_basecamp_custom_post_types')):
    add_action('init', 'manang_basecamp_custom_post_types',8);
    function manang_basecamp_custom_post_types() {

        $postTypes = array(
            'Slider'         => array('postType' => 'Slider', 'dashicon' => 'dashicons-format-gallery', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => 'editor', 'support-comment' => '' ),
            'Portfolio'       => array('postType' => 'Portfolio', 'dashicon' => 'dashicons-admin-home', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => 'editor', 'support-comment' => 'comments'),
            'Testimonial'       => array('postType' => 'Testimonial', 'dashicon' => 'dashicons-megaphone', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => 'editor', 'support-comment' => ''),
            'Team'       => array('postType' => 'Team', 'dashicon' => 'dashicons-universal-access', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => 'editor', 'support-comment' => ''),
            'Clients'       => array('postType' => 'Clients', 'dashicon' => 'dashicons-image-filter', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => 'editor', 'support-comment' => ''),
            'Counter'       => array('postType' => 'Counter', 'dashicon' => 'dashicons-image-filter', 'supports-thumbnail' => '', 'supports-editor' => '', 'support-comment' => ''),
            'Pricing'       => array('postType' => 'Pricing', 'dashicon' => 'dashicons-image-filter', 'supports-thumbnail' => 'thumbnail', 'supports-editor' => '', 'support-comment' => ''),
            'Event'       => array('postType' => 'Event', 'dashicon' => 'dashicons-image-filter', 'supports-thumbnail' => '', 'supports-editor' => '', 'support-comment' => ''),
            'Music'       => array('postType' => 'Music', 'dashicon' => 'dashicons-image-filter', 'supports-thumbnail' => '', 'supports-editor' => '', 'support-comment' => ''),

        );

        foreach ($postTypes as $postType) {
            $dashicon = $postType['dashicon'];
            $supports = $postType['supports-thumbnail'];
            $editor = $postType['supports-editor'];
            $comment = $postType['support-comment'];
            $singular_title = $postType['postType'];
            $labels = array(
                'name'=> $singular_title . 's',
                'singular_name' => $singular_title,
                'menu_name'=> $singular_title. 's',
                'name_admin_bar'=> $singular_title. 's',
                'parent_item_colon'=> __('Parent ', 'manang-basecamp'). $singular_title ,
                'all_items'=> __('All ', 'manang-basecamp'). $singular_title. 's',
                'add_new_item'=> __('Add New ', 'manang-basecamp'). $singular_title,
                'add_new'=> __('Add New ', 'manang-basecamp'). $singular_title,
                'new_item'=> __('New ', 'manang-basecamp'). $singular_title,
                'edit_item'=> __('Edit ', 'manang-basecamp'). $singular_title,
                'update_item'=> __('Update ', 'manang-basecamp'). $singular_title,
                'view_item'=> __('View ', 'manang-basecamp'). $singular_title,
                'search_items'=> __('Search ', 'manang-basecamp'). $singular_title,
                'not_found'=> __('Not found', 'manang-basecamp'),
                'not_found_in_trash'=> __('Not found in Trash', 'manang-basecamp'),
            );
            $args = array(
                'label'=> $singular_title,
                'description'=> $singular_title. __(' post type for themes', 'manang-basecamp'),
                'labels'=> $labels,
                'supports'=> array( 'title', $editor, $supports, $comment ),
                'hierarchical'=> true,
                'rewrite' => array(
                        'slug' => 'manang-'.sanitize_title($singular_title)),
                'public'=> true,
                'show_ui'=> true,
                'show_in_menu'=> true,
                'menu_position'=> 5,
                'menu_icon'=> $dashicon,
                'show_in_admin_bar'=> true,
                'show_in_nav_menus'=> true,
                'can_export'=> true,
                'has_archive'=> true,
                'exclude_from_search'=> false,
                'publicly_queryable'=> true,
                'capability_type'=>'page',
            );

          register_post_type($singular_title, $args);
          // flush_rewrite_rules();

          if ($singular_title == 'Team') {
              register_taxonomy( 'team_category', // register custom taxonomy - category
                  'team',
                  array(
                      'hierarchical' => true,
                      'rewrite'       => array('slug' => 'team_category'),
                      'labels' => array(
                          'name' => 'Team categories',
                          'singular_name' => 'Feature category',
                      )
                  )
              );
          }
          if ($singular_title == 'Portfolio') {
              register_taxonomy( 'portfolio_category', // register custom taxonomy - category
                  'portfolio',
                  array(
                      'hierarchical' => true,
                      'rewrite'       => array('slug' => 'portfolio_category'),
                      'labels' => array(
                          'name' => 'Portfolio categories',
                          'singular_name' => 'Portfolio category',
                      )
                  )
              );
          }
          if ($singular_title == 'Testimonial') {
              register_taxonomy( 'testimonial_category', // register custom taxonomy - category
                  'testimonial',
                  array(
                      'hierarchical' => true,
                      'rewrite'       => array('slug' => 'testimonial_category'),
                      'labels' => array(
                          'name' => 'Testimonial categories',
                          'singular_name' => 'Testimonial category',
                      )
                  )
              );
          }
          if ($singular_title == 'Event') {
              register_taxonomy( 'event_category', // register custom taxonomy - category
                  'event',
                  array(
                      'hierarchical' => true,
                      'rewrite'       => array('slug' => 'event_category'),
                      'labels' => array(
                          'name' => 'Event categories',
                          'singular_name' => 'Event category',
                      )
                  )
              );
          }

        }

    }
endif;

function manang_rewrite_flush() {
    manang_basecamp_custom_post_types();

    flush_rewrite_rules();
}
