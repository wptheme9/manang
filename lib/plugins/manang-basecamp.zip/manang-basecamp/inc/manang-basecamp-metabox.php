<?php if (!function_exists('manang_basecamp_add_metabox')) {
    function manang_basecamp_add_metabox() {
            add_meta_box(
                'manang_basecamp_features',
                __('Add Icons And Texts', 'manang-basecamp'),
                'manang_basecamp_counter_callback',
                'counter','normal'
            );

            add_meta_box(
                'manang_basecamp_accomodation_metas',
                __('Accomodation Options','manang-basecamp'),
                'manang_basecam_team_meta_box',
                'team',
                'normal'
            );

            add_meta_box(
                'manang_basecamp_features',
                __('Add Link', 'manang-basecamp'),
                'manang_basecamp_clients_callback',
                'clients','side'
            );

            add_meta_box(
                'manang_basecamp_features',
                __('Add Designation', 'manang-basecamp'),
                'manang_basecamp_testimonial_callback',
                'testimonial','side'
            );

            add_meta_box(
                'manang_basecamp_pricing',
                __('Pricing Contents', 'manang-basecamp'),
                'manang_basecamp_pricing_callback',
                'pricing','normal'
            );

            add_meta_box(
                'manang_basecamp_event',
                __('Event Contents', 'manang-basecamp'),
                'manang_basecamp_event_callback',
                'event','normal'
            );

            add_meta_box(
                'manang_basecamp_portfolio',
                __('Portfolio Contents', 'manang-basecamp'),
                'manang_basecamp_portfolio_callback',
                'portfolio','normal'
            );
    }
    add_action('add_meta_boxes', 'manang_basecamp_add_metabox');
}


// The Callback
function manang_basecam_team_meta_box() {
    // Field Array
    $prefix = 'manang_basecamp_team_';
    $custom_meta_fields = array(
        array(
            'label'=> 'Designation',
            'desc'  => '',
            'id'    => $prefix.'designation',
            'type'  => 'text'
        ),
        array(
            'label'=> 'Facebook',
            'desc'  => 'Facebook Link.',
            'id'    => $prefix.'facebook',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Twitter',
            'desc'  => 'Twitter Link.',
            'id'    => $prefix.'twitter',
            'type'  => 'text'
        ),

          array(
            'label'=> 'Gmail',
            'desc'  => 'Gmail Link.',
            'id'    => $prefix.'gmail',
            'type'  => 'text'
        ),

        array(
            'label' => 'Pinterest',
            'desc'  => 'Pinterest Link.',
            'id'    => $prefix.'pinterest',
            'type'  => 'text'
        ),
    );
    global $post;
    // Use nonce for verification
    echo '<input type="hidden" name="manang_basecamp_option_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';

    // Begin the field table and loop
    echo '<table class="form-table">';
    foreach ($custom_meta_fields as $field) {
        // get value of this field if it exists for this post
        $meta = get_post_meta($post->ID, $field['id'], true);
        // begin a table row with
        echo '<tr>
                <th><label for="'.$field['id'].'">'.$field['label'].'</label></th>
                <td>';
                switch($field['type']) {
                    // case items will go here
                    // text
                    case 'text':
                        echo '<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="30" />
                            <br /><span class="description">'.$field['desc'].'</span>';
                    break;

                    // textarea
                    case 'textarea':
                        echo '<textarea name="'.$field['id'].'" id="'.$field['id'].'" cols="60" rows="4">'.$meta.'</textarea>
                            <br /><span class="description">'.$field['desc'].'</span>';
                    break;

                    // repeatable
                    case 'repeatable':
                        echo '
                                <ul id="'.$field['id'].'-repeatable" class="custom_repeatable">';
                        $i = 0;

                        if ($meta) {
                            foreach($meta as $row) {
                                echo '<li>
                                            <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$row.'" size="30" />';?>
                                        <?php
                                         echo '<a class="repeatable-remove button" href="#">-</a></li>';
                                $i++;
                            }
                        } else {
                            echo '<li>
                                       <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$meta.'" size="30" />

                                            <a class="repeatable-remove button" href="#">-</a></li>';
                        }
                        echo '</ul><a class="repeatable-add button" href="#">Add</a>
                            ';
                    break;

                    case 'select':
                        $items = array (
                            'ion-wineglass', 'ion-umbrella', 'ion-plane'
                        );
                            echo '<ul class="custom_repeatable"><li><select name="'.$field['id'].'" id="'.$field['id'].'">
                                    <option value="">Select Icon</option>'; // Select One
                                foreach($items as $item) {
                                    echo '<option value="'.$item.'"',$meta == $item ? ' selected="selected"' : '','>'.$item.'</option>';
                                } // end foreach
                            echo '</select><br /><span class="description">'.$field['desc'].'</span></li></ul>';
                    break;

                    // checkbox
                    case 'checkbox':
                        echo '<input type="checkbox" name="'.$field['id'].'" id="'.$field['id'].'" ',$meta ? ' checked="checked"' : '','/>
                            <label for="'.$field['id'].'">'.$field['desc'].'</label>';
                    break;
                } //end switch
        echo '</td></tr>';
    } // end foreach
    echo '</table>'; // end table
}


// Save the Data
function save_custom_meta($post_id, $post) {
    $prefix = 'manang_basecamp_team_';
   $custom_meta_fields = array(
         array(
            'label'=> 'Designation',
            'desc'  => '',
            'id'    => $prefix.'designation',
            'type'  => 'text'
        ),
        array(
            'label'=> 'Facebook',
            'desc'  => 'Facebook link.',
            'id'    => $prefix.'facebook',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Twitter',
            'desc'  => 'Twitter Link.',
            'id'    => $prefix.'twitter',
            'type'  => 'text'
        ),

          array(
            'label'=> 'Gmail',
            'desc'  => 'Gmail link.',
            'id'    => $prefix.'gmail',
            'type'  => 'text'
        ),

        array(
            'label' => 'Pinterest',
            'desc'  => 'Pinterest Link.',
            'id'    => $prefix.'pinterest',
            'type'  => 'text'
        ),
    );

   if (empty($_POST['manang_basecamp_option_nonce'])){
    return $post_id;
   }
    // verify nonce
    if (!wp_verify_nonce($_POST['manang_basecamp_option_nonce'], basename(__FILE__)))
        return $post_id;
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;
    // check permissions
    if ( !current_user_can( 'edit_post', $post->ID ))
            return $post->ID;

    // loop through fields and save the data
    foreach ($custom_meta_fields as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    } // end foreach
}
add_action('save_post', 'save_custom_meta', 1, 2);

if(!function_exists('manang_basecamp_counter_callback')):
    function manang_basecamp_counter_callback( $post ) {

        wp_nonce_field( 'manang_basecamp_counter_save_meta_box_data', 'counter_meta_box_nonce' );

        $counter_icon_class = get_post_meta( $post->ID, 'counter_icon_class', true );
        $counter_number = get_post_meta( $post->ID, 'counter_number', true );
        $counter_text = get_post_meta( $post->ID, 'counter_text', true );

        $href = esc_url('http://ionicons.com');
        $format = '<a href="%s" target="_blank">' . __("Ionicons","manang") . '</a>';
        echo sprintf($format, $href);
        echo '<br />';
        echo '<label for="counter_icon_class">';
        _e( 'Add Icon', 'manang-basecamp' );
        echo '</label> ';
        echo '<br />';
        echo '<input type="text" id="counter_icon_class" placeholder="ion-ios-briefcase-outline" name="counter_icon_class" value="' . esc_attr( $counter_icon_class ) . '" size="25" />';
        echo '<br />';

        echo '<label for="counter_number">';
        _e( 'Add Number', 'manang-basecamp' );
        echo '</label> ';
        echo '<input type="text" id="counter_number" name="counter_number" value="' . esc_attr( $counter_number ) . '" size="25" />';
        echo '<br />';

        echo '<label for="counter_text">';
        _e( 'Add Text', 'manang-basecamp' );
        echo '</label> ';
        echo '<input type="text" id="counter_text" name="counter_text" value="' . esc_attr( $counter_text ) . '" size="25" />';
        echo '<br />';
    }
endif;

if(!function_exists('manang_basecamp_counter_save_meta_box_data')):
    function manang_basecamp_counter_save_meta_box_data( $post_id ) {
        if ( ! isset( $_POST['counter_meta_box_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['counter_meta_box_nonce'], 'manang_basecamp_counter_save_meta_box_data' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }

        } else {

            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }

        if ( ! isset( $_POST['counter_icon_class'] ) ) {
            return;
        }
        if ( ! isset( $_POST['counter_number'] ) ) {
            return;
        }
        if ( ! isset( $_POST['counter_text'] ) ) {
            return;
        }
        $counter_icon_class = sanitize_text_field( $_POST['counter_icon_class'] );
        update_post_meta( $post_id, 'counter_icon_class', $counter_icon_class );
        $counter_number = sanitize_text_field( $_POST['counter_number'] );
        update_post_meta( $post_id, 'counter_number', $counter_number );
        $counter_text = sanitize_text_field( $_POST['counter_text'] );
        update_post_meta( $post_id, 'counter_text', $counter_text );
    }
    add_action( 'save_post', 'manang_basecamp_counter_save_meta_box_data' );
endif;

if(!function_exists('manang_basecamp_clients_callback')):
    function manang_basecamp_clients_callback( $post ) {

        wp_nonce_field( 'manang_basecamp_clients_save_meta_box_data', 'clients_meta_box_nonce' );

        $manang_basecamp_clients_link = get_post_meta( $post->ID, 'manang_basecamp_clients_link', true );

        echo '<input type="text" id="manang_basecamp_clients_link" name="manang_basecamp_clients_link" value="' . esc_url( $manang_basecamp_clients_link ) . '" size="25" />';
        echo '<br />';
    }
endif;

if(!function_exists('manang_basecamp_testimonial_callback')):
    function manang_basecamp_testimonial_callback( $post ) {

        wp_nonce_field( 'manang_basecamp_testimonial_save_meta_box_data', 'testimonial_meta_box_nonce' );

        $manang_basecamp_testimonial_designation = get_post_meta( $post->ID, 'manang_basecamp_testimonial_designation', true );

        echo '<input type="text" id="manang_basecamp_testimonial_designation" name="manang_basecamp_testimonial_designation" value="' . esc_html( $manang_basecamp_testimonial_designation ) . '" size="25" />';
        echo '<br />';
    }
endif;

if(!function_exists('manang_basecamp_clients_save_meta_box_data')):
    function manang_basecamp_clients_save_meta_box_data( $post_id ) {
        if ( ! isset( $_POST['clients_meta_box_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['clients_meta_box_nonce'], 'manang_basecamp_clients_save_meta_box_data' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }

        } else {

            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }

        if ( ! isset( $_POST['manang_basecamp_clients_link'] ) ) {
            return;
        }
        $manang_basecamp_clients_link = sanitize_text_field( $_POST['manang_basecamp_clients_link'] );
        update_post_meta( $post_id, 'manang_basecamp_clients_link', $manang_basecamp_clients_link );
    }
    add_action( 'save_post', 'manang_basecamp_clients_save_meta_box_data' );
endif;

if(!function_exists('manang_basecamp_testimonial_save_meta_box_data')):
    function manang_basecamp_testimonial_save_meta_box_data( $post_id ) {
        if ( ! isset( $_POST['testimonial_meta_box_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['testimonial_meta_box_nonce'], 'manang_basecamp_testimonial_save_meta_box_data' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }

        } else {

            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }

        if ( ! isset( $_POST['manang_basecamp_testimonial_designation'] ) ) {
            return;
        }
        $manang_basecamp_testimonial_designation = sanitize_text_field( $_POST['manang_basecamp_testimonial_designation'] );
        update_post_meta( $post_id, 'manang_basecamp_testimonial_designation', $manang_basecamp_testimonial_designation );
    }
    add_action( 'save_post', 'manang_basecamp_testimonial_save_meta_box_data' );
endif;

// The Callback
function manang_basecamp_pricing_callback() {
    $prefix = 'manang_basecamp_pricing_';
    $custom_meta_fields = array(
        array(
            'label'=> 'Plan Name',
            'desc'  => '',
            'id'    => $prefix.'plan_name',
            'type'  => 'text'
        ),
        array(
            'label'=> 'Price',
            'desc'  => '',
            'id'    => $prefix.'price',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Currency Symbol',
            'desc'  => '',
            'id'    => $prefix.'currency',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Period',
            'desc'  => 'monthly,yearly,daily',
            'id'    => $prefix.'period',
            'type'  => 'text'
        ),

        array(
            'label' => 'Features',
            'desc'  => 'Add Features.',
            'id'    => $prefix.'features',
            'type'  => 'repeatable'
        ),

        array(
            'label'=> 'Button Text',
            'desc'  => 'Add Text for button.',
            'id'    => $prefix.'button_text',
            'type'  => 'text'
        ),

        array(
            'label' => 'Button Link',
            'desc'  => 'Add URL for Button.',
            'id'    => $prefix.'button_link',
            'type'  => 'text'
        ),

        array(
            'label' => 'Want to make this pricing table featured?',
            'desc'  => 'Select to make featured.',
            'id'    => $prefix.'featured',
            'type'  => 'checkbox'
        ),
    );
    global $post;
    // Use nonce for verification
    echo '<input type="hidden" name="manang_basecamp_pricing_nonce" value="'.wp_create_nonce(basename(__FILE__)).'" />';

    // Begin the field table and loop
    echo '<table class="form-table">';
    foreach ($custom_meta_fields as $field) {
        // get value of this field if it exists for this post
        $meta = get_post_meta($post->ID, $field['id'], true);
        // begin a table row with
        echo '<tr>
                <th><label for="'.$field['id'].'">'.$field['label'].'</label></th>
                <td>';
                switch($field['type']) {
                    // case items will go here
                    // text
                    case 'text':
                        echo '<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="30" />
                            <br /><span class="description">'.$field['desc'].'</span>';
                    break;

                    case 'checkbox':
                        echo '<input type="checkbox" name="'.$field['id'].'" id="'.$field['id'].'" ',$meta ? ' checked="checked"' : '','/>
                            <label for="'.$field['id'].'">'.$field['desc'].'</label>';
                    break;

                    case 'repeatable':
                        echo '
                                <ul id="'.$field['id'].'-repeatable" class="custom_repeatable">';
                        $i = 0;

                        if ($meta) {
                            foreach($meta as $row) {
                                echo '<li>
                                            <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$row.'" size="30" />';?>
                                        <?php
                                         echo '<a class="repeatable-remove button" href="#">-</a></li>';
                                $i++;
                            }
                        } else {
                            echo '<li>
                                       <input type="text" name="'.$field['id'].'['.$i.']" id="'.$field['id'].'" value="'.$meta.'" size="30" />

                                            <a class="repeatable-remove button" href="#">-</a></li>';
                        }
                        echo '</ul><a class="repeatable-add button" href="#">Add</a>
                            ';
                    break;
                } //end switch
        echo '</td></tr>';
    } // end foreach
    echo '</table>'; // end table
}

function manang_basecamp_save_pricing_meta($post_id, $post) {
    $prefix = 'manang_basecamp_pricing_';
    $custom_meta_fields = array(
        array(
            'label'=> 'Plan Name',
            'desc'  => '',
            'id'    => $prefix.'plan_name',
            'type'  => 'text'
        ),
        array(
            'label'=> 'Price',
            'desc'  => '',
            'id'    => $prefix.'price',
            'type'  => 'text'
        ),

         array(
            'label'=> 'Currency Symbol',
            'desc'  => '',
            'id'    => $prefix.'currency',
            'type'  => 'text'
        ),

        array(
            'label'=> 'Period',
            'desc'  => 'monthly,yearly,daily',
            'id'    => $prefix.'period',
            'type'  => 'text'
        ),

        array(
            'label' => 'Features',
            'desc'  => 'Add Features.',
            'id'    => $prefix.'features',
            'type'  => 'repeatable'
        ),

        array(
            'label'=> 'Button Text',
            'desc'  => 'Add Text for button.',
            'id'    => $prefix.'button_text',
            'type'  => 'text'
        ),

        array(
            'label' => 'Button Link',
            'desc'  => 'Add URL for Button.',
            'id'    => $prefix.'button_link',
            'type'  => 'text'
        ),

        array(
            'label' => 'Want to make this pricing table featured?',
            'desc'  => 'Select to make featured.',
            'id'    => $prefix.'featured',
            'type'  => 'checkbox'
        ),
    );

   if (empty($_POST['manang_basecamp_pricing_nonce'])){
    return $post_id;
   }
    // verify nonce
    if (!wp_verify_nonce($_POST['manang_basecamp_pricing_nonce'], basename(__FILE__)))
        return $post_id;
    // check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return $post_id;
    // check permissions
    if ( !current_user_can( 'edit_post', $post->ID ))
            return $post->ID;

    // loop through fields and save the data
    foreach ($custom_meta_fields as $field) {
        $old = get_post_meta($post_id, $field['id'], true);
        $new = $_POST[$field['id']];
        if ($new && $new != $old) {
            update_post_meta($post_id, $field['id'], $new);
        } elseif ('' == $new && $old) {
            delete_post_meta($post_id, $field['id'], $old);
        }
    } // end foreach
}
add_action('save_post', 'manang_basecamp_save_pricing_meta', 1, 2);