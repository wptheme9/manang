<?php
if(!function_exists('manang_basecamp_service_callback')):
    function manang_basecamp_service_callback( $post ) {

        wp_nonce_field( 'manang_basecamp_service_save_meta_box_data', 'service_meta_box_nonce' );

        $service_icon_class = get_post_meta( $post->ID, 'service_icon_class', true );

        $href = esc_url('http://ionicons.com');
        $format = '<a href="%s" target="_blank">' . __("Ionicons","manang") . '</a>';
        echo sprintf($format, $href);
        echo '<br />';
        echo '<label for="service_icon_class">';
        _e( 'Add Icon', 'manang-basecamp' );
        echo '</label> ';
        echo '<br />';
        echo '<input type="text" id="service_icon_class" placeholder="ion-ios-briefcase-outline" name="service_icon_class" value="' . esc_attr( $service_icon_class ) . '" size="25" />';
        echo '<br />';

    }
endif;

if(!function_exists('manang_basecamp_service_save_meta_box_data')):
    function manang_basecamp_service_save_meta_box_data( $post_id ) {
        if ( ! isset( $_POST['service_meta_box_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['service_meta_box_nonce'], 'manang_basecamp_service_save_meta_box_data' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }

        } else {

            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }

        if ( ! isset( $_POST['service_icon_class'] ) ) {
            return;
        }
        $service_icon_class = sanitize_text_field( $_POST['service_icon_class'] );
        update_post_meta( $post_id, 'service_icon_class', $service_icon_class );
    }
    add_action( 'save_post', 'manang_basecamp_service_save_meta_box_data' );
endif;