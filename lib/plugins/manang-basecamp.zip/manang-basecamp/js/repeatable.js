jQuery(document).ready(function() {
    jQuery('.repeatable-add').click(function() {
        field = jQuery(this).closest('td').find('.custom_repeatable li:last').clone(true);
        fieldLocation = jQuery(this).closest('td').find('.custom_repeatable li:last');
        jQuery('input', field).val('').attr('name', function(index, name) {
            return name.replace(/(\d+)/, function(fullMatch, n) {
                return Number(n) + 1;
            });
        })
        field.insertAfter(fieldLocation, jQuery(this).closest('td'))
        return false;
    });

    jQuery('.repeatable-remove').click(function(){
        if(jQuery('.repeatable-remove').length > 1) {
            jQuery(this).parent().remove();
            return false;
            }
    });

    // jQuery('.metabox_submit').click(function(e) {
    //     e.preventDefault();
    //     jQuery('#publish').click();
    // });
    // jQuery('#add-row').on('click', function() {
    //     var row = jQuery('.empty-row.screen-reader-text').clone(true);
    //     row.removeClass('empty-row screen-reader-text');
    //     row.find("#options-test").attr("id", "options");
    //     row.insertBefore('#repeatable-fieldset-one tbody>tr:last');
    //      jQuery("select#options").selectBoxIt();
    //     return false;
    // });
    // jQuery('.remove-row').on('click', function() {
    //     jQuery(this).parents('tr').remove();
    //     return false;
    // });

    // jQuery("select#options").selectBoxIt();
});